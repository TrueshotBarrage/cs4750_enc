# cs4750_dependencies

Holds specific versions (NOT Git submodules) of MuSHR dependencies required for the Fall 2021 offering of CS4750. 
