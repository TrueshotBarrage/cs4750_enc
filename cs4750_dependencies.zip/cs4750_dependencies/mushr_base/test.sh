#!/bin/bash

# python2 -m unittest discover test
