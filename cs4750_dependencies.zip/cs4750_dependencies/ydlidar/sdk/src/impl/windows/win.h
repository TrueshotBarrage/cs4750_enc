#pragma once

#include <stddef.h>
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>   
#include <process.h>
#include <direct.h> 


